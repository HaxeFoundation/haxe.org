local _hx_print = print or (function()end)
