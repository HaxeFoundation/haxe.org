#!/bin/sh
haxe --run tools.haxelib.Main $@
