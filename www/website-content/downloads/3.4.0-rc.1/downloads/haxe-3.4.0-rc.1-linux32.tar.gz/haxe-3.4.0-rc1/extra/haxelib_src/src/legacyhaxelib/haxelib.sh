#!/bin/sh
exec haxe --run legacyhaxelib.Main "$@"
