#!/bin/sh
haxe --run tools.haxedoc.Main $@
